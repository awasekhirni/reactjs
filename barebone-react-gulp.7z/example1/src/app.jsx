import HelloWorld from './hello-world';
import React from 'react';
import ReactDOM from 'react-dom';
ReactDOM.render(
    <HelloWorld phrase="Syed! Hello you fool i love you!"></HelloWorld>,
    document.querySelector('.root')
);