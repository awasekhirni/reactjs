import React from 'react';
import ReactDOM from 'react-dom'; 
import RootComponent from './js/components/root.component.js';

//binding to the view
ReactDOM.render(<RootComponent/>,document.getElementById('react-app'));