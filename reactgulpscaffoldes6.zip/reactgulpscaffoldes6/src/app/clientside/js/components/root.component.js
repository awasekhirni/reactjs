import React from 'react';

class RootComponent extends React.Component{

    //must be there to render the component html/jsx files
    render(){
        return(
            <h1>DanskeIT:DEMO</h1>
        );
    }

}

export default RootComponent;